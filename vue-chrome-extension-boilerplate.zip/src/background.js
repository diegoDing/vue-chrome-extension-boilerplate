// @ts-ignore
import { test } from './content/test';
test();
console.log('backgroun就绪', import.meta.env.DEV);
//# sourceMappingURL=background.js.map