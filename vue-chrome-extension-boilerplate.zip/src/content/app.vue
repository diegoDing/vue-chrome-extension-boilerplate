<template>
  <div class="test-a">Nihaoaaaasdsad</div>
</template>

<script>
export default {
  name: "index"
}
</script>

<style scoped>
.test-a{
  font-size: 40px;
}
</style>
