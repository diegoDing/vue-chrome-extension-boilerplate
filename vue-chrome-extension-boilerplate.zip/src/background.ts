import {getBaiduHtml} from "./api";

getBaiduHtml()
console.log('backgroun就绪',import.meta.env.DEV)
